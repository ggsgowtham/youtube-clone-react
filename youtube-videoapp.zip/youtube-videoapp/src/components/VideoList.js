import React from 'react';
import VideoItem from './VideoItem';

const VideoList = props => {
    const videoItemsList = props.videos.map(video => {
        return (
            <VideoItem key = {video.id.videoId} video={video} onVideoSelect = {props.onVideoSelect} />
        )
    });
    return (
        <div className="ui relaxed divided list">
            {videoItemsList}
        </div>
    );
};

export default VideoList;